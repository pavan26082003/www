# eFactor NAS — Storage Plans Feature

This package adds:

1. **Get more storage** button to the existing NAS Home storage card.
2. A new premium/light-dark **Storage Plans** page.
3. Server-side plan validation.
4. Transactional update of the existing `users.storage_limit` field.
5. No change to the existing dashboard/storage API logic.

## Why the existing APIs update automatically

The current NAS dashboard/file APIs already read:

```sql
SELECT storage_used, storage_limit
FROM users
WHERE id = ?
```

Therefore after a successful plan activation, existing Home and Dashboard storage
indicators automatically use the new quota on their next normal API load.

## Files

Copy:

- `app/Config/NasStoragePlans.php`
- `app/Services/NAS/StoragePlanService.php`
- `app/Controllers/NAS/Web/StoragePlanController.php`
- `app/Views/NAS/storage_plans/index.php`

Replace your current:

- `app/Views/NAS/home/index.php`

with:

- `app/Views/NAS/home/index.php` from this package.

Add the two route lines from:

- `routes/NasRoutes_storage_plans_patch.php`

to your existing `app/Config/NasRoutes.php`.

## Database

No new table or column is required for the basic feature.

The existing NAS `users` table already has:

- `storage_used`
- `storage_limit`

The plan upgrade updates only:

```sql
UPDATE users
SET storage_limit = ?
WHERE id = ?
```

The capacity is resolved from the server-side `NasStoragePlans` config. The browser
does **not** send storage bytes.

## Plan semantics

Plans are TOTAL quota.

Example:

- Current limit: 10 GB
- User chooses 50 GB Growth
- New `storage_limit`: 50 GB

It does NOT become 60 GB.

Plans equal to or smaller than the current quota are disabled.

## Current sample plan capacities

Edit `app/Config/NasStoragePlans.php` to change these business values:

- Plus: 25 GB
- Growth: 50 GB
- Pro: 100 GB
- Business: 250 GB

## Payment / billing

This package intentionally does not invent a payment gateway.

`directActivationEnabled = true` means clicking a plan immediately grants the quota,
which is suitable for your current internal/testing stage.

Before selling storage publicly:

1. Set `directActivationEnabled = false`.
2. Create the checkout/payment flow.
3. After the payment provider verifies payment server-side, call:
   `StoragePlanService::activatePlan($nasUserId, $planCode)`.
4. Never trust plan size, price or payment-success values coming from browser JavaScript.

## Quick verification

After copying files and routes:

1. Open `/index.php/NAS/home`.
2. Click **Get more storage**.
3. Open `/index.php/NAS/storage-plans`.
4. Select a plan larger than the current quota.
5. Return to Home or Dashboard.
6. The existing `/NAS/api/v1/dashboard` response should now show the new `storage.limit`
   and `limit_formatted`.

Direct DB check:

```sql
SELECT id, username, storage_used, storage_limit
FROM users
WHERE id = YOUR_NAS_USER_ID;
```
