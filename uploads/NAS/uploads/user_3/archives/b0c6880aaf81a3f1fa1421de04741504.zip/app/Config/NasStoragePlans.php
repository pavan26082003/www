<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

/**
 * NAS storage plans.
 *
 * storage_gb is the TOTAL storage quota assigned to the user.
 * Example: selecting 50 GB sets users.storage_limit to 50 GB.
 *
 * IMPORTANT:
 * directActivationEnabled=true is suitable for internal/testing use where
 * selecting a plan immediately grants the quota.
 *
 * If these become paid plans, set directActivationEnabled=false and call
 * StoragePlanService::activatePlan() only after your payment provider has
 * verified a successful payment on the server/webhook side.
 */
class NasStoragePlans extends BaseConfig
{
    public bool $directActivationEnabled = true;

    public array $plans = [
        'plus-25' => [
            'code' => 'plus-25',
            'name' => 'Plus',
            'storage_gb' => 25,
            'badge' => '',
            'description' => 'More room for documents, photos and daily backups.',
            'features' => [
                '25 GB total NAS storage',
                'Files, folders and sharing',
                'Browser synchronization',
            ],
        ],

        'growth-50' => [
            'code' => 'growth-50',
            'name' => 'Growth',
            'storage_gb' => 50,
            'badge' => 'Popular',
            'description' => 'A balanced plan for growing workspaces and teams.',
            'features' => [
                '50 GB total NAS storage',
                'Files, folders and sharing',
                'Browser synchronization',
                'More room for project content',
            ],
        ],

        'pro-100' => [
            'code' => 'pro-100',
            'name' => 'Pro',
            'storage_gb' => 100,
            'badge' => '',
            'description' => 'For larger project libraries and frequent uploads.',
            'features' => [
                '100 GB total NAS storage',
                'Files, folders and sharing',
                'Browser synchronization',
                'Suitable for larger media libraries',
            ],
        ],

        'business-250' => [
            'code' => 'business-250',
            'name' => 'Business',
            'storage_gb' => 250,
            'badge' => '',
            'description' => 'Higher capacity for demanding business workloads.',
            'features' => [
                '250 GB total NAS storage',
                'Files, folders and sharing',
                'Browser synchronization',
                'High-capacity workspace',
            ],
        ],
    ];
}
