<?php

namespace App\Controllers\NAS\Web;

use App\Services\NAS\StoragePlanService;
use Config\Services;

class StoragePlanController
{
    private StoragePlanService $storagePlanService;

    public function __construct()
    {
        $this->storagePlanService = new StoragePlanService();
    }

    public function index()
    {
        $session = Services::session();
        $userId = (int) $session->get('nas_user_id');

        if ($userId <= 0) {
            return redirect()->to(site_url('signin'));
        }

        try {
            $storage = $this->storagePlanService->getUserStorage($userId);
            $plans = $this->storagePlanService->getPlans();
        } catch (\Throwable $e) {
            log_message(
                'error',
                'NAS storage plans page failed: ' . $e->getMessage()
            );

            $session->setFlashdata(
                'nas_storage_error',
                'Unable to load storage plans right now.'
            );

            return redirect()->to(site_url('NAS/home'));
        }

        $username = trim((string) $session->get('nas_display_name'));

        if ($username === '') {
            $username = (string) ($session->get('nas_username') ?: 'User');
        }

        return view('NAS/storage_plans/index', [
            'basePath' => rtrim(site_url('NAS'), '/'),
            'assetsBase' => rtrim(base_url('assets/NAS'), '/'),
            'username' => $username,
            'userInitial' => strtoupper(substr($username ?: 'U', 0, 1)),
            'storage' => $storage,
            'plans' => $plans,
            'directActivationEnabled' =>
                $this->storagePlanService->isDirectActivationEnabled(),
        ]);
    }

    public function activate()
    {
        $session = Services::session();
        $userId = (int) $session->get('nas_user_id');

        if ($userId <= 0) {
            return redirect()->to(site_url('signin'));
        }

        if (!$this->storagePlanService->isDirectActivationEnabled()) {
            $session->setFlashdata(
                'nas_storage_error',
                'Direct plan activation is disabled. Complete payment first.'
            );

            return redirect()->to(site_url('NAS/storage-plans'));
        }

        $planCode = trim((string) ($_POST['plan_code'] ?? ''));

        try {
            $result = $this->storagePlanService->activatePlan(
                $userId,
                $planCode
            );

            $session->setFlashdata(
                'nas_storage_success',
                'Storage upgraded successfully to '
                . $result['new_limit_formatted']
                . '.'
            );
        } catch (\Throwable $e) {
            log_message(
                'error',
                'NAS storage plan activation failed for user '
                . $userId
                . ': '
                . $e->getMessage()
            );

            $session->setFlashdata(
                'nas_storage_error',
                $e->getMessage()
            );
        }

        return redirect()->to(site_url('NAS/storage-plans'));
    }
}
