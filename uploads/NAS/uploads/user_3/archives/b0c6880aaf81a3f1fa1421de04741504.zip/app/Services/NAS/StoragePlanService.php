<?php

namespace App\Services\NAS;

use App\Repositories\NAS\UserRepository;
use Config\NasStoragePlans;
use PDO;
use RuntimeException;

class StoragePlanService
{
    private UserRepository $userRepository;
    private NasStoragePlans $config;

    public function __construct(
        ?UserRepository $userRepository = null,
        ?NasStoragePlans $config = null
    ) {
        $this->userRepository = $userRepository ?? new UserRepository();
        $this->config = $config ?? new NasStoragePlans();
    }

    /**
     * Return normalized public plan data.
     */
    public function getPlans(): array
    {
        $plans = [];

        foreach ($this->config->plans as $code => $plan) {
            $storageGb = (int) ($plan['storage_gb'] ?? 0);

            if ($storageGb <= 0) {
                continue;
            }

            $plans[$code] = [
                'code' => (string) ($plan['code'] ?? $code),
                'name' => (string) ($plan['name'] ?? $code),
                'storage_gb' => $storageGb,
                'storage_bytes' => $this->gbToBytes($storageGb),
                'badge' => (string) ($plan['badge'] ?? ''),
                'description' => (string) ($plan['description'] ?? ''),
                'features' => array_values(
                    is_array($plan['features'] ?? null)
                        ? $plan['features']
                        : []
                ),
            ];
        }

        uasort(
            $plans,
            static fn(array $a, array $b): int =>
                $a['storage_bytes'] <=> $b['storage_bytes']
        );

        return $plans;
    }

    /**
     * Read the current live NAS quota from the existing users table.
     */
    public function getUserStorage(int $userId): array
    {
        if ($userId <= 0) {
            throw new RuntimeException('Invalid NAS user');
        }

        $pdo = $this->userRepository->getPdo();

        $stmt = $pdo->prepare(
            'SELECT id, storage_used, storage_limit
             FROM users
             WHERE id = ?
             LIMIT 1'
        );

        $stmt->execute([$userId]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$row) {
            throw new RuntimeException('NAS user not found');
        }

        $used = (int) ($row['storage_used'] ?? 0);
        $limit = (int) ($row['storage_limit'] ?? 0);

        return [
            'user_id' => (int) $row['id'],
            'used' => $used,
            'limit' => $limit,
            'used_formatted' => $this->formatBytes($used),
            'limit_formatted' => $this->formatBytes($limit),
            'percentage' => $limit > 0
                ? min(100, max(0, ($used / $limit) * 100))
                : 0,
        ];
    }

    /**
     * Activate one SERVER-DEFINED storage plan.
     *
     * The browser only supplies plan_code. The browser never supplies bytes.
     * This method locks the user row, validates that the chosen plan is a
     * real upgrade, and writes users.storage_limit transactionally.
     */
    public function activatePlan(int $userId, string $planCode): array
    {
        if ($userId <= 0) {
            throw new RuntimeException('Invalid NAS user');
        }

        $planCode = trim($planCode);

        $plans = $this->getPlans();

        if ($planCode === '' || !isset($plans[$planCode])) {
            throw new RuntimeException('Invalid storage plan selected');
        }

        $plan = $plans[$planCode];
        $newLimit = (int) $plan['storage_bytes'];

        if ($newLimit <= 0) {
            throw new RuntimeException('Invalid storage plan capacity');
        }

        $pdo = $this->userRepository->getPdo();

        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare(
                'SELECT storage_used, storage_limit
                 FROM users
                 WHERE id = ?
                 LIMIT 1
                 FOR UPDATE'
            );

            $stmt->execute([$userId]);

            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                throw new RuntimeException('NAS user not found');
            }

            $used = (int) ($user['storage_used'] ?? 0);
            $oldLimit = (int) ($user['storage_limit'] ?? 0);

            if ($newLimit <= $oldLimit) {
                throw new RuntimeException(
                    'Choose a plan larger than your current storage limit'
                );
            }

            if ($newLimit < $used) {
                throw new RuntimeException(
                    'Selected plan is smaller than your current storage usage'
                );
            }

            $update = $pdo->prepare(
                'UPDATE users
                 SET storage_limit = ?
                 WHERE id = ?'
            );

            $update->execute([
                $newLimit,
                $userId,
            ]);

            if ($update->rowCount() < 1) {
                throw new RuntimeException('Storage limit was not updated');
            }

            $pdo->commit();

            log_message(
                'info',
                sprintf(
                    'NAS storage plan activated: user=%d plan=%s old_limit=%d new_limit=%d',
                    $userId,
                    $planCode,
                    $oldLimit,
                    $newLimit
                )
            );

            return [
                'success' => true,
                'plan' => $plan,
                'old_limit' => $oldLimit,
                'new_limit' => $newLimit,
                'old_limit_formatted' => $this->formatBytes($oldLimit),
                'new_limit_formatted' => $this->formatBytes($newLimit),
            ];
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            throw $e;
        }
    }

    public function isDirectActivationEnabled(): bool
    {
        return $this->config->directActivationEnabled === true;
    }

    private function gbToBytes(int $gb): int
    {
        return $gb * 1024 * 1024 * 1024;
    }

    public function formatBytes(int $bytes): string
    {
        if ($bytes <= 0) {
            return '0 B';
        }

        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $size = (float) $bytes;
        $unitIndex = 0;

        while ($size >= 1024 && $unitIndex < count($units) - 1) {
            $size /= 1024;
            $unitIndex++;
        }

        $decimals = $unitIndex >= 3 ? 0 : 2;

        return rtrim(
            rtrim(number_format($size, $decimals, '.', ''), '0'),
            '.'
        ) . ' ' . $units[$unitIndex];
    }
}
