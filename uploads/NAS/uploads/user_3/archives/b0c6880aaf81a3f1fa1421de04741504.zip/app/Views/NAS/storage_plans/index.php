<?php

$basePath = isset($basePath) && $basePath !== ''
    ? rtrim($basePath, '/')
    : rtrim(site_url('NAS'), '/');

$assetsBase = isset($assetsBase) && $assetsBase !== ''
    ? rtrim($assetsBase, '/')
    : rtrim(base_url('assets/NAS'), '/');

$username = (string) ($username ?? 'User');
$userInitial = (string) ($userInitial ?? strtoupper(substr($username ?: 'U', 0, 1)));
$storage = is_array($storage ?? null) ? $storage : [];
$plans = is_array($plans ?? null) ? $plans : [];

$successMessage = (string) (session()->getFlashdata('nas_storage_success') ?? '');
$errorMessage = (string) (session()->getFlashdata('nas_storage_error') ?? '');

$currentLimit = (int) ($storage['limit'] ?? 0);
$currentUsed = (int) ($storage['used'] ?? 0);
$percentage = (float) ($storage['percentage'] ?? 0);
$percentage = max(0, min(100, $percentage));

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script>
    (function () {
        try {
            var savedTheme = localStorage.getItem('efactor_nas_home_theme');
            document.documentElement.setAttribute(
                'data-nas-theme',
                savedTheme === 'dark' ? 'dark' : 'light'
            );
        } catch (e) {
            document.documentElement.setAttribute('data-nas-theme', 'light');
        }
    })();
    </script>

    <title>Storage Plans - eFactor NAS</title>

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    >

    <style>
    :root {
        --plan-bg: #f5f7fb;
        --plan-surface: #ffffff;
        --plan-surface-soft: #fafbfe;
        --plan-text: #202431;
        --plan-strong: #161a24;
        --plan-muted: #6f7787;
        --plan-subtle: #9ba3b2;
        --plan-border: #e4e8ef;
        --plan-border-strong: #d5dbe5;

        --plan-primary: #6257d9;
        --plan-primary-dark: #4f46b8;
        --plan-primary-soft: #f0efff;

        --plan-green: #168269;
        --plan-green-soft: #eaf8f3;

        --plan-amber: #ad7616;
        --plan-amber-soft: #fff6e4;

        --plan-red: #c5525c;
        --plan-red-soft: #fff0f2;

        --plan-shadow: 0 8px 25px rgba(29, 38, 59, .06);
        --plan-shadow-hover: 0 18px 42px rgba(29, 38, 59, .11);
    }

    html[data-nas-theme="dark"] {
        --plan-bg: #10141c;
        --plan-surface: #181d27;
        --plan-surface-soft: #1d2330;
        --plan-text: #dfe5ef;
        --plan-strong: #f6f8fb;
        --plan-muted: #98a3b5;
        --plan-subtle: #717d90;
        --plan-border: #293241;
        --plan-border-strong: #354153;

        --plan-primary: #9789ff;
        --plan-primary-dark: #b2a8ff;
        --plan-primary-soft: rgba(134, 119, 255, .14);

        --plan-green: #4cd0a8;
        --plan-green-soft: rgba(76, 208, 168, .12);

        --plan-amber: #e9b94f;
        --plan-amber-soft: rgba(233, 185, 79, .12);

        --plan-red: #ff7d88;
        --plan-red-soft: rgba(255, 125, 136, .12);

        --plan-shadow: 0 8px 28px rgba(0, 0, 0, .18);
        --plan-shadow-hover: 0 20px 48px rgba(0, 0, 0, .28);
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    html,
    body {
        min-height: 100%;
    }

    body {
        min-height: 100vh;
        font-family:
            Inter,
            -apple-system,
            BlinkMacSystemFont,
            "Segoe UI",
            Roboto,
            Arial,
            sans-serif;
        background: var(--plan-bg);
        color: var(--plan-text);
        -webkit-font-smoothing: antialiased;
    }

    .plan-header {
        position: sticky;
        top: 0;
        z-index: 100;
        min-height: 66px;
        padding: 0 clamp(18px, 3vw, 42px);
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
        border-bottom: 1px solid var(--plan-border);
        background: color-mix(in srgb, var(--plan-surface) 95%, transparent);
        backdrop-filter: blur(14px);
        -webkit-backdrop-filter: blur(14px);
    }

    .brand {
        display: flex;
        align-items: center;
        gap: 11px;
        color: var(--plan-text);
        text-decoration: none;
    }

    .logo-mark {
        width: 40px;
        height: 40px;
        display: grid;
        place-items: center;
        border: 1px solid var(--plan-border);
        border-radius: 11px;
        background: #fff;
    }

    .logo-mark img {
        max-width: 30px;
        max-height: 30px;
        object-fit: contain;
    }

    .brand-copy {
        display: flex;
        flex-direction: column;
    }

    .brand-name {
        color: var(--plan-strong);
        font-size: 16px;
        font-weight: 700;
    }

    .brand-subtitle {
        margin-top: 2px;
        color: var(--plan-muted);
        font-size: 10.5px;
    }

    .header-actions {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .header-btn,
    .theme-btn {
        min-height: 38px;
        padding: 0 13px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 7px;
        border: 1px solid var(--plan-border);
        border-radius: 10px;
        background: var(--plan-surface);
        color: var(--plan-text);
        text-decoration: none;
        cursor: pointer;
        font-size: 12.5px;
        font-weight: 650;
        transition:
            transform .18s ease,
            border-color .18s ease,
            background .18s ease;
    }

    .theme-btn {
        width: 40px;
        padding: 0;
        color: var(--plan-primary);
    }

    html[data-nas-theme="dark"] .theme-btn {
        color: var(--plan-amber);
        background: var(--plan-amber-soft);
    }

    .header-btn:hover,
    .theme-btn:hover {
        transform: translateY(-1px);
        border-color: var(--plan-border-strong);
        background: var(--plan-surface-soft);
    }

    .user-chip {
        height: 40px;
        padding: 4px 10px 4px 4px;
        display: flex;
        align-items: center;
        gap: 8px;
        border: 1px solid var(--plan-border);
        border-radius: 999px;
        background: var(--plan-surface);
    }

    .avatar {
        width: 31px;
        height: 31px;
        display: grid;
        place-items: center;
        border-radius: 50%;
        color: #fff;
        background: linear-gradient(135deg, #6257d9, #7d70e6);
        font-size: 12px;
        font-weight: 750;
    }

    .user-name {
        max-width: 150px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        color: var(--plan-text);
        font-size: 12.5px;
        font-weight: 600;
    }

    .plans-main {
        width: min(1240px, calc(100% - 40px));
        margin: 0 auto;
        padding: 34px 0 56px;
    }

    .hero {
        padding: clamp(27px, 4vw, 42px);
        display: grid;
        grid-template-columns: minmax(0, 1fr) auto;
        gap: 30px;
        align-items: center;
        border: 1px solid var(--plan-border);
        border-radius: 20px;
        background:
            linear-gradient(
                125deg,
                var(--plan-surface) 0%,
                var(--plan-surface) 58%,
                var(--plan-primary-soft) 100%
            );
        box-shadow: var(--plan-shadow);
    }

    .hero-badge {
        width: fit-content;
        padding: 6px 10px;
        display: inline-flex;
        align-items: center;
        gap: 7px;
        border-radius: 999px;
        background: var(--plan-primary-soft);
        color: var(--plan-primary-dark);
        font-size: 10.5px;
        font-weight: 750;
    }

    .hero h1 {
        margin-top: 12px;
        max-width: 760px;
        color: var(--plan-strong);
        font-size: clamp(29px, 3.5vw, 43px);
        line-height: 1.12;
        letter-spacing: -1px;
    }

    .hero p {
        max-width: 680px;
        margin-top: 10px;
        color: var(--plan-muted);
        font-size: 14px;
        line-height: 1.65;
    }

    .hero-icon {
        width: 112px;
        height: 112px;
        display: grid;
        place-items: center;
        border: 1px solid var(--plan-border);
        border-radius: 31px;
        background: var(--plan-primary-soft);
        color: var(--plan-primary);
        font-size: 36px;
    }

    .message {
        margin-top: 18px;
        padding: 13px 15px;
        display: flex;
        align-items: center;
        gap: 10px;
        border: 1px solid var(--plan-border);
        border-radius: 12px;
        font-size: 12.5px;
        font-weight: 600;
    }

    .message.success {
        background: var(--plan-green-soft);
        color: var(--plan-green);
        border-color: color-mix(in srgb, var(--plan-green) 23%, var(--plan-border));
    }

    .message.error {
        background: var(--plan-red-soft);
        color: var(--plan-red);
        border-color: color-mix(in srgb, var(--plan-red) 23%, var(--plan-border));
    }

    .current-storage {
        margin-top: 22px;
        padding: 18px 20px;
        display: grid;
        grid-template-columns: auto minmax(0, 1fr) auto;
        align-items: center;
        gap: 16px;
        border: 1px solid var(--plan-border);
        border-radius: 15px;
        background: var(--plan-surface);
        box-shadow: var(--plan-shadow);
    }

    .current-icon {
        width: 44px;
        height: 44px;
        display: grid;
        place-items: center;
        border-radius: 12px;
        background: var(--plan-primary-soft);
        color: var(--plan-primary);
    }

    .current-storage h2 {
        color: var(--plan-strong);
        font-size: 14px;
        font-weight: 700;
    }

    .current-storage p {
        margin-top: 3px;
        color: var(--plan-muted);
        font-size: 11px;
    }

    .usage-bar {
        width: 100%;
        height: 7px;
        margin-top: 10px;
        overflow: hidden;
        border-radius: 999px;
        background: var(--plan-border);
    }

    .usage-fill {
        height: 100%;
        border-radius: inherit;
        background: linear-gradient(90deg, #6257d9, #7c70e7);
    }

    .current-number {
        text-align: right;
    }

    .current-number strong {
        display: block;
        color: var(--plan-strong);
        font-size: 18px;
    }

    .current-number span {
        color: var(--plan-muted);
        font-size: 10.5px;
    }

    .section-heading {
        margin: 30px 0 14px;
    }

    .section-heading h2 {
        color: var(--plan-strong);
        font-size: 19px;
        font-weight: 750;
    }

    .section-heading p {
        margin-top: 4px;
        color: var(--plan-muted);
        font-size: 12px;
    }

    .plans-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 14px;
    }

    .plan-card {
        position: relative;
        min-height: 380px;
        padding: 22px;
        display: flex;
        flex-direction: column;
        border: 1px solid var(--plan-border);
        border-radius: 17px;
        background: var(--plan-surface);
        box-shadow: var(--plan-shadow);
        overflow: hidden;
        transition:
            transform .22s cubic-bezier(.2,.8,.2,1),
            border-color .22s ease,
            box-shadow .22s ease;
    }

    .plan-card:hover {
        transform: translateY(-4px);
        border-color: color-mix(in srgb, var(--plan-primary) 28%, var(--plan-border));
        box-shadow: var(--plan-shadow-hover);
    }

    .plan-card.recommended {
        border-color: color-mix(in srgb, var(--plan-primary) 42%, var(--plan-border));
    }

    .plan-badge {
        position: absolute;
        top: 14px;
        right: 14px;
        padding: 5px 8px;
        border-radius: 999px;
        background: var(--plan-primary-soft);
        color: var(--plan-primary-dark);
        font-size: 9.5px;
        font-weight: 750;
    }

    .plan-icon {
        width: 42px;
        height: 42px;
        display: grid;
        place-items: center;
        border-radius: 11px;
        background: var(--plan-primary-soft);
        color: var(--plan-primary);
        font-size: 16px;
    }

    .plan-card h3 {
        margin-top: 17px;
        color: var(--plan-strong);
        font-size: 17px;
    }

    .capacity {
        margin-top: 7px;
        color: var(--plan-strong);
        font-size: 31px;
        font-weight: 780;
        letter-spacing: -.8px;
    }

    .capacity span {
        margin-left: 4px;
        color: var(--plan-muted);
        font-size: 12px;
        font-weight: 600;
        letter-spacing: 0;
    }

    .plan-description {
        min-height: 58px;
        margin-top: 9px;
        color: var(--plan-muted);
        font-size: 11.5px;
        line-height: 1.55;
    }

    .feature-list {
        margin: 16px 0 20px;
        display: grid;
        gap: 10px;
        list-style: none;
    }

    .feature-list li {
        display: flex;
        gap: 8px;
        align-items: flex-start;
        color: var(--plan-text);
        font-size: 11px;
        line-height: 1.4;
    }

    .feature-list i {
        margin-top: 2px;
        color: var(--plan-green);
    }

    .plan-action {
        margin-top: auto;
    }

    .plan-button {
        width: 100%;
        min-height: 42px;
        padding: 0 14px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        border: 1px solid transparent;
        border-radius: 10px;
        background: var(--plan-primary);
        color: #fff;
        cursor: pointer;
        font-size: 12px;
        font-weight: 700;
        transition:
            transform .18s ease,
            background .18s ease,
            box-shadow .18s ease;
    }

    .plan-button:hover {
        transform: translateY(-1px);
        background: var(--plan-primary-dark);
        box-shadow: 0 8px 18px rgba(98, 87, 217, .20);
    }

    .plan-button:disabled {
        cursor: default;
        transform: none;
        color: var(--plan-muted);
        background: var(--plan-surface-soft);
        border-color: var(--plan-border);
        box-shadow: none;
    }

    .direct-note {
        margin-top: 18px;
        padding: 13px 15px;
        border: 1px solid var(--plan-border);
        border-radius: 12px;
        background: var(--plan-surface-soft);
        color: var(--plan-muted);
        font-size: 10.5px;
        line-height: 1.55;
    }

    .direct-note i {
        margin-right: 6px;
        color: var(--plan-amber);
    }

    @media (max-width: 1050px) {
        .plans-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }
    }

    @media (max-width: 720px) {
        .plan-header {
            padding: 0 12px;
        }

        .brand-copy,
        .user-name,
        .header-btn span {
            display: none;
        }

        .header-btn {
            width: 40px;
            padding: 0;
        }

        .user-chip {
            padding-right: 4px;
            border-color: transparent;
            background: transparent;
        }

        .plans-main {
            width: calc(100% - 24px);
            padding-top: 20px;
        }

        .hero {
            grid-template-columns: 1fr;
            padding: 25px 22px;
        }

        .hero-icon {
            display: none;
        }

        .current-storage {
            grid-template-columns: auto minmax(0, 1fr);
        }

        .current-number {
            grid-column: 2;
            text-align: left;
        }
    }

    @media (max-width: 580px) {
        .plans-grid {
            grid-template-columns: 1fr;
        }

        .plan-card {
            min-height: auto;
        }
    }

    @media (prefers-reduced-motion: reduce) {
        *,
        *::before,
        *::after {
            animation: none !important;
            transition: none !important;
        }
    }
    </style>
</head>
<body>

<header class="plan-header">
    <a href="<?= esc($basePath) ?>/home" class="brand">
        <span class="logo-mark">
            <img
                src="<?= esc($assetsBase) ?>/images/efactor.png"
                alt="eFactor"
            >
        </span>

        <span class="brand-copy">
            <span class="brand-name">eFactor NAS</span>
            <span class="brand-subtitle">Storage Plans</span>
        </span>
    </a>

    <div class="header-actions">
        <button
            type="button"
            class="theme-btn"
            id="planThemeToggle"
            title="Switch theme"
            aria-label="Switch theme"
        >
            <i class="fas fa-moon"></i>
        </button>

        <div class="user-chip">
            <span class="avatar"><?= esc($userInitial) ?></span>
            <span class="user-name"><?= esc($username) ?></span>
        </div>

        <a
            href="<?= esc($basePath) ?>/home"
            class="header-btn"
            title="Back to NAS Home"
        >
            <i class="fas fa-arrow-left"></i>
            <span>Back</span>
        </a>
    </div>
</header>

<main class="plans-main">

    <section class="hero">
        <div>
            <div class="hero-badge">
                <i class="fas fa-database"></i>
                Storage upgrade
            </div>

            <h1>Give your workspace more room to grow.</h1>

            <p>
                Choose a larger NAS storage plan. Your existing files stay exactly
                where they are; only your account storage limit is increased.
            </p>
        </div>

        <div class="hero-icon" aria-hidden="true">
            <i class="fas fa-cloud-arrow-up"></i>
        </div>
    </section>

    <?php if ($successMessage !== ''): ?>
        <div class="message success">
            <i class="fas fa-circle-check"></i>
            <?= esc($successMessage) ?>
        </div>
    <?php endif; ?>

    <?php if ($errorMessage !== ''): ?>
        <div class="message error">
            <i class="fas fa-circle-exclamation"></i>
            <?= esc($errorMessage) ?>
        </div>
    <?php endif; ?>

    <section class="current-storage">
        <div class="current-icon">
            <i class="fas fa-hard-drive"></i>
        </div>

        <div>
            <h2>Current storage</h2>
            <p>
                <?= esc((string) ($storage['used_formatted'] ?? '0 B')) ?>
                used of
                <?= esc((string) ($storage['limit_formatted'] ?? '0 B')) ?>
            </p>

            <div class="usage-bar">
                <div
                    class="usage-fill"
                    style="width: <?= esc((string) $percentage) ?>%"
                ></div>
            </div>
        </div>

        <div class="current-number">
            <strong>
                <?= esc((string) ($storage['limit_formatted'] ?? '0 B')) ?>
            </strong>
            <span>Current quota</span>
        </div>
    </section>

    <div class="section-heading">
        <h2>Choose more storage</h2>
        <p>
            Plans below represent the total storage quota after upgrade.
        </p>
    </div>

    <section class="plans-grid">
        <?php foreach ($plans as $plan): ?>
            <?php
                $planLimit = (int) ($plan['storage_bytes'] ?? 0);
                $canUpgrade = $planLimit > $currentLimit;
                $badge = trim((string) ($plan['badge'] ?? ''));
            ?>

            <article
                class="plan-card <?= $badge !== '' ? 'recommended' : '' ?>"
            >
                <?php if ($badge !== ''): ?>
                    <span class="plan-badge">
                        <?= esc($badge) ?>
                    </span>
                <?php endif; ?>

                <div class="plan-icon">
                    <i class="fas fa-cloud"></i>
                </div>

                <h3><?= esc((string) ($plan['name'] ?? 'Storage')) ?></h3>

                <div class="capacity">
                    <?= esc((string) ($plan['storage_gb'] ?? 0)) ?>
                    <span>GB total</span>
                </div>

                <p class="plan-description">
                    <?= esc((string) ($plan['description'] ?? '')) ?>
                </p>

                <ul class="feature-list">
                    <?php foreach (($plan['features'] ?? []) as $feature): ?>
                        <li>
                            <i class="fas fa-check"></i>
                            <span><?= esc((string) $feature) ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>

                <div class="plan-action">
                    <form
                        method="post"
                        action="<?= esc($basePath) ?>/storage-plans/activate"
                        onsubmit="return confirm('Upgrade your NAS storage to <?= esc((string) ($plan['storage_gb'] ?? 0)) ?> GB?');"
                    >
                        <?= csrf_field() ?>

                        <input
                            type="hidden"
                            name="plan_code"
                            value="<?= esc((string) ($plan['code'] ?? '')) ?>"
                        >

                        <button
                            type="submit"
                            class="plan-button"
                            <?= $canUpgrade && $directActivationEnabled ? '' : 'disabled' ?>
                        >
                            <?php if (!$canUpgrade): ?>
                                <i class="fas fa-check"></i>
                                Current / smaller plan
                            <?php elseif (!$directActivationEnabled): ?>
                                <i class="fas fa-lock"></i>
                                Payment required
                            <?php else: ?>
                                <i class="fas fa-arrow-up"></i>
                                Get <?= esc((string) ($plan['storage_gb'] ?? 0)) ?> GB
                            <?php endif; ?>
                        </button>
                    </form>
                </div>
            </article>
        <?php endforeach; ?>
    </section>

    <div class="direct-note">
        <i class="fas fa-shield-halved"></i>
        The browser sends only a plan code. Storage capacity is resolved on the
        server and written to the existing NAS <strong>users.storage_limit</strong>
        field. Arbitrary client-side quota values are not accepted.
    </div>

</main>

<script>
(function () {
    'use strict';

    const STORAGE_KEY = 'efactor_nas_home_theme';
    const root = document.documentElement;
    const button = document.getElementById('planThemeToggle');

    function getTheme() {
        return root.getAttribute('data-nas-theme') === 'dark'
            ? 'dark'
            : 'light';
    }

    function renderButton() {
        if (!button) return;

        const dark = getTheme() === 'dark';
        const icon = button.querySelector('i');

        if (icon) {
            icon.className = dark
                ? 'fas fa-sun'
                : 'fas fa-moon';
        }

        button.title = dark
            ? 'Switch to light theme'
            : 'Switch to dark theme';

        button.setAttribute(
            'aria-label',
            button.title
        );
    }

    if (button) {
        button.addEventListener('click', function () {
            const next = getTheme() === 'dark'
                ? 'light'
                : 'dark';

            root.setAttribute(
                'data-nas-theme',
                next
            );

            try {
                localStorage.setItem(
                    STORAGE_KEY,
                    next
                );
            } catch (e) {}

            renderButton();
        });
    }

    renderButton();
})();
</script>

</body>
</html>
