<?php

/*
|--------------------------------------------------------------------------
| NAS Storage Plans - add these routes to app/Config/NasRoutes.php
|--------------------------------------------------------------------------
|
| Place these near the existing NAS/home and NAS/dashboard web routes.
| Your existing NAS authentication filter/session bridge remains unchanged.
|
*/

$routes->get(
    'NAS/storage-plans',
    'NAS\Web\StoragePlanController::index'
);

$routes->post(
    'NAS/storage-plans/activate',
    'NAS\Web\StoragePlanController::activate'
);
